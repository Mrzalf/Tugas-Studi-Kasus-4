#include <iostream>
#include <fstream>
#include "../library/input.h"

int main(){
	Input input;
	input.cetak();
	input.toFile();
	return 0;
}